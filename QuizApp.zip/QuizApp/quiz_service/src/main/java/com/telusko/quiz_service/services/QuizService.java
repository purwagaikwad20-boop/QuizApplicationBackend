package com.telusko.quiz_service.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.telusko.quiz_service.feign.Quizinterface;
import com.telusko.quiz_service.model.QuestionWrapper;
import com.telusko.quiz_service.model.Quiz;
import com.telusko.quiz_service.model.Response;
import com.telusko.quiz_service.repository.QuizRepository;

@Service
public class QuizService {
	
	@Autowired
	QuizRepository quizRepo;

	@Autowired
	Quizinterface quizInterface;

	public ResponseEntity<String> createQuiz(String catagory, Integer numQ, String title) {
		System.out.println("Category = " + catagory);
		System.out.println("NumQ = " + numQ);
		List<Integer> qustions = quizInterface.getQuestionsForQuiz(catagory, numQ).getBody();
		Quiz quiz = new Quiz();
		quiz.setTitle(title);
		quiz.setQuestion(qustions);
		quizRepo.save(quiz);
			return new ResponseEntity<>("Success", HttpStatus.CREATED);
	}

	public ResponseEntity<List<QuestionWrapper>> getQuizQuestions(Integer id) {
		
		  Quiz quiz = quizRepo.findById(id).get(); 
          List<Integer> questionsIds = quiz.getQuestion();
          quizInterface.getQuestionsFromId(questionsIds);
          ResponseEntity<List<QuestionWrapper>> questions = quizInterface.getQuestionsFromId(questionsIds);
		return questions;
	}

	public ResponseEntity<Integer> calculate(Integer id, List<Response> response) {
      ResponseEntity<Integer> score =  quizInterface.getScore(response);
		return score;
	}


}
