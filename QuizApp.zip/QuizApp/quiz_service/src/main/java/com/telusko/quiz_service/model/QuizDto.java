package com.telusko.quiz_service.model;

import lombok.Data;

@Data
public class QuizDto {
	
	String catagoryName;
	Integer numQuestions;
    String title;

}
