package com.telusko.quiz_service.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.telusko.quiz_service.model.QuestionWrapper;
import com.telusko.quiz_service.model.Response;


@FeignClient("QUESTION-SERVICE")
public interface Quizinterface  {

	  @GetMapping("questions/generate")
	  public ResponseEntity<List<Integer>> getQuestionsForQuiz(@RequestParam String catagroyName, @RequestParam Integer numQuestions);
	  
	  @PostMapping("questions/getQuestions")
	  public ResponseEntity<List<QuestionWrapper>> getQuestionsFromId(@RequestBody List<Integer> questionIds);
	  
	  @PostMapping("questions/getScore")
	  public ResponseEntity<Integer> getScore(@RequestBody List<Response> responses);
}
