package com.telusko.quizeapp.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.telusko.quizeapp.model.Question;
import com.telusko.quizeapp.repository.QuestionRepo;

@Service
public class QuestionService {

	@Autowired
	QuestionRepo questionRepo;
	
	public ResponseEntity<List<Question>>  getAllQuestions() {
		try {
			return new  ResponseEntity<>(questionRepo.findAll(),HttpStatus.OK);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return new  ResponseEntity<>(new ArrayList<>(),HttpStatus.OK);
		
	}

	public ResponseEntity<List<Question>>  findByCatagory(String catagory) {
		try {
			return new ResponseEntity<>( questionRepo.findByCatagory(catagory), HttpStatus.OK);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>( new ArrayList<>(), HttpStatus.OK);
	}

	public ResponseEntity<String>  addQuestion(Question question) {
	    System.out.println("DEBUG QUESTION = " + question);

	    questionRepo.save(question);

	    return new ResponseEntity<String>( "Created", HttpStatus.CREATED);
	}

	public String deleteQuestion(Integer id) {
		questionRepo.deleteById(id);
		return "Deleted";
	}

	public Question updateQuestion(Question question) {
		Question oldId = questionRepo.findById(question.getId()).orElse(null);
		if(oldId != null) {
			oldId.setCatagory(question.getCatagory());
			oldId.setDifficultyLevel(question.getDifficultyLevel());
			oldId.setOption1(question.getOption1());
			oldId.setOption2(question.getOption2());
			oldId.setOption3(question.getOption3());
			oldId.setOption4(question.getOption4());
			oldId.setQuestionTitle(question.getQuestionTitle());
			oldId.setRightAnswer(question.getRightAnswer());
		}
		return questionRepo.save(oldId);
	}

}
