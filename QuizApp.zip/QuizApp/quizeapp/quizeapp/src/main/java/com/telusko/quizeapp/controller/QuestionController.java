package com.telusko.quizeapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.telusko.quizeapp.model.Question;
import com.telusko.quizeapp.services.QuestionService;

@RestController
@RequestMapping("/questions")
public class QuestionController {
	
	@Autowired
	QuestionService questionService;
	
  @GetMapping("/allQuestions")
   public ResponseEntity<List<Question>> getAllQuestions() {
	   return questionService.getAllQuestions();
   }
  
  @GetMapping("/catagory/{catagory}")
  public ResponseEntity<List<Question>>  getQuestionByCatagory(@PathVariable String catagory){
	return questionService.findByCatagory(catagory);
	  
  }
  
  @PostMapping("/add")
  public ResponseEntity<String> addQuestion(@RequestBody Question quesiton) {
	  	return questionService.addQuestion(quesiton);
	  
  }
  
  @DeleteMapping("/delete/id/{id}")
  public String deleteQuestion(@PathVariable Integer id) {
	  return questionService.deleteQuestion(id);
  }
  
  @PutMapping("/update")
  public Question updateQuestion(@RequestBody Question question) {
	return questionService.updateQuestion(question);
	  
  }
}
