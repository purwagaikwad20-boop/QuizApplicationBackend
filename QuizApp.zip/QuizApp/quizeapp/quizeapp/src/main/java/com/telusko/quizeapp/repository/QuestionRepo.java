package com.telusko.quizeapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.telusko.quizeapp.model.Question;

@Repository
public interface QuestionRepo  extends JpaRepository<Question, Integer>{

	List<Question> findByCatagory(String catagory);

	@Query(value = "SELECT * FROM question q WHERE q.catagory = :catagory ORDER BY RAND()", nativeQuery = true)
	List<Question> findRandomQuestionsByCatagory(String catagory, Integer numQ);

}
