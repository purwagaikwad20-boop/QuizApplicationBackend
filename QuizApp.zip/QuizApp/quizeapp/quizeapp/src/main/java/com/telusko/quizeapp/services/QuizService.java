package com.telusko.quizeapp.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.telusko.quizeapp.model.Question;
import com.telusko.quizeapp.model.QuestionWrapper;
import com.telusko.quizeapp.model.Quiz;
import com.telusko.quizeapp.model.Response;
import com.telusko.quizeapp.repository.QuestionRepo;
import com.telusko.quizeapp.repository.QuizRepository;

@Service
public class QuizService {
	
	@Autowired
	QuizRepository quizRepo;
	
	@Autowired
	QuestionRepo questionRepo;

	public ResponseEntity<String> createQuiz(String catagory, Integer numQ, String title) {
			List<Question> questions = questionRepo.findRandomQuestionsByCatagory(catagory,numQ);
			List<Question> limitedQuestions = questions.stream().limit(numQ).toList();
			Quiz quiz = new Quiz();
			quiz.setTitle(title);
			quiz.setQuestion(limitedQuestions);
			
			quizRepo.save(quiz);
			
			return new ResponseEntity<>("Success", HttpStatus.CREATED);
	}

	public ResponseEntity<List<QuestionWrapper>> getQuizQuestions(Integer id) {
		Optional<Quiz> quiz =  quizRepo.findById(id);
		List<Question> questionsFromDb = quiz.get().getQuestion();
		List<QuestionWrapper>questionsForUser = new ArrayList<QuestionWrapper>();
		for(Question q : questionsFromDb) {
			QuestionWrapper qw = new QuestionWrapper(q.getId(), q.getQuestionTitle(), q.getOption1(), q.getOption2(), q.getOption3(), q.getOption4());
			questionsForUser.add(qw);
		}
		
		return new ResponseEntity<>(questionsForUser, HttpStatus.OK);
	}

	public ResponseEntity<Integer> calculate(Integer id, List<Response> response) {
        Quiz quiz = quizRepo.findById(id).get();
        List<Question> question = quiz.getQuestion();
        int right =0;
        int i = 0;
        for(Response res : response ) {
        	if(res.getResponse().equals(question.get(i).getRightAnswer())) 
        		right++;      	    
        	i++;
        }
		return new ResponseEntity<>(right, HttpStatus.OK);
	}


}
