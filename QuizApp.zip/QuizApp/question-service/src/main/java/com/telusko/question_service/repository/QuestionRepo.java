package com.telusko.question_service.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.telusko.question_service.model.Question;

@Repository
public interface QuestionRepo  extends JpaRepository<Question, Integer>{

	List<Question> findByCatagory(String catagory);

	@Query(value = "SELECT q.id FROM question q WHERE q.catagory = :catagory ORDER BY RAND()", nativeQuery = true)
	List<Integer> findRandomQuestionsByCatagory(String catagory,Pageable pageable);

	
}
