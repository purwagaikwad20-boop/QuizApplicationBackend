package com.telusko.question_service.controller;

import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.telusko.question_service.model.Question;
import com.telusko.question_service.model.QuestionWrapper;
import com.telusko.question_service.model.Response;
import com.telusko.question_service.services.QuestionService;

@RestController
@RequestMapping("/questions")
public class QuestionController {
	
	@Autowired
	QuestionService questionService;
	
	@Autowired
	Environment environment;
	
  @GetMapping("/allQuestions")
   public ResponseEntity<List<Question>> getAllQuestions() {
	   return questionService.getAllQuestions();
   }
  
  @GetMapping("/catagory/{catagory}")
  public ResponseEntity<List<Question>>  getQuestionByCatagory(@PathVariable String catagory){
	return questionService.findByCatagory(catagory);
	  
  }
  
  @PostMapping("/add")
  public ResponseEntity<String> addQuestion(@RequestBody Question quesiton) {
	  	return questionService.addQuestion(quesiton);
	  
  }
  
  @DeleteMapping("/delete/id/{id}")
  public String deleteQuestion(@PathVariable Integer id) {
	  return questionService.deleteQuestion(id);
  }
  
  @PutMapping("/update")
  public Question updateQuestion(@RequestBody Question question) {
	return questionService.updateQuestion(question);
	  
  }
  
  @GetMapping("/generate")
  public ResponseEntity<List<Integer>> getQuestionsForQuiz(@RequestParam String catagroyName, @RequestParam Integer numQuestions){
	  return questionService.getQuestionsForQuiz(catagroyName,numQuestions);
  }
  
  @PostMapping("getQuestions")
  public ResponseEntity<List<QuestionWrapper>> getQuestionsFromId(@RequestBody List<Integer> questionIds){
	  System.out.println(environment.getProperty("localhost.server.port"));
	  return questionService.getQuestionsFromId(questionIds);
  }
  
  @PostMapping("getScore")
  public ResponseEntity<Integer> getScore(@RequestBody List<Response> responses){
	  return questionService.getScore(responses);
	  
  }
  
}

