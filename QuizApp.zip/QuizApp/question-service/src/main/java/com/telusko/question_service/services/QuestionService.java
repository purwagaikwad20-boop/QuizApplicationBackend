package com.telusko.question_service.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.telusko.question_service.model.Question;
import com.telusko.question_service.model.QuestionWrapper;
import com.telusko.question_service.model.Response;
import com.telusko.question_service.repository.QuestionRepo;


@Service
public class QuestionService {

	@Autowired
	QuestionRepo questionRepo;
	
	public ResponseEntity<List<Question>>  getAllQuestions() {
		try {
			return new  ResponseEntity<>(questionRepo.findAll(),HttpStatus.OK);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return new  ResponseEntity<>(new ArrayList<>(),HttpStatus.OK);
		
	}

	public ResponseEntity<List<Question>>  findByCatagory(String catagory) {
		try {
			return new ResponseEntity<>( questionRepo.findByCatagory(catagory), HttpStatus.OK);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>( new ArrayList<>(), HttpStatus.OK);
	}

	public ResponseEntity<String>  addQuestion(Question question) {
	    System.out.println("DEBUG QUESTION = " + question);

	    questionRepo.save(question);

	    return new ResponseEntity<String>( "Created", HttpStatus.CREATED);
	}

	public String deleteQuestion(Integer id) {
		questionRepo.deleteById(id);
		return "Deleted";
	}

	public Question updateQuestion(Question question) {
		Question oldId = questionRepo.findById(question.getId()).orElse(null);
		if(oldId != null) {
			oldId.setCatagory(question.getCatagory());
			oldId.setDifficultyLevel(question.getDifficultyLevel());
			oldId.setOption1(question.getOption1());
			oldId.setOption2(question.getOption2());
			oldId.setOption3(question.getOption3());
			oldId.setOption4(question.getOption4());
			oldId.setQuestionTitle(question.getQuestionTitle());
			oldId.setRightAnswer(question.getRightAnswer());
		}
		return questionRepo.save(oldId);
	}

	public ResponseEntity<List<Integer>> getQuestionsForQuiz(String catagoryName,Integer numQuestions) {
		Pageable pageable = PageRequest.of(0, numQuestions);
		List<Integer> questions = questionRepo.findRandomQuestionsByCatagory(catagoryName,pageable);
		return new ResponseEntity<>(questions, HttpStatus.OK);

	}

	public ResponseEntity<List<QuestionWrapper>> getQuestionsFromId(List<Integer> questionIds) {
		List<QuestionWrapper> wrappers = new ArrayList<QuestionWrapper>();
		List<Question> questions = new ArrayList<Question>();
		
		for(Integer id : questionIds) {
			questions.add(questionRepo.findById(id).get());
		}
		
		for(Question question : questions) {
			QuestionWrapper wrapper = new QuestionWrapper();
			wrapper.setId(question.getId());
			wrapper.setQuestionTitle(question.getQuestionTitle());
			wrapper.setOption1(question.getOption1());
			wrapper.setOption2(question.getOption2());
			wrapper.setOption3(question.getOption3());
			wrapper.setOption4(question.getOption4());
			wrappers.add(wrapper);
		}
		
		return new ResponseEntity<>(wrappers, HttpStatus.OK);
	}

	public ResponseEntity<Integer> getScore(List<Response> responses) {
	        int right =0;
	        for(Response res : responses ) {
	        	Question question = questionRepo.findById(res.getId()).get();
	        	if(res.getResponse().equals(question.getRightAnswer())) 
	        		right++;      	    
	        }
			return new ResponseEntity<>(right, HttpStatus.OK);
	}

}
